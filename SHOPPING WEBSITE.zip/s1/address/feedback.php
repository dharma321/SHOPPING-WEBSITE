<?php 
ob_start(); 
require 'config.php';

$name = $_POST['name'];
$doorno = $_POST['doorno'];
$street = $_POST['street'];
$additional = $_POST['additional'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];
$state = $_POST['state'];


$query = mysqli_query($con, "INSERT INTO `address`(`name`, `doorno`, `street`, `additional`, `city` , 'pincode' , 'state') VALUES ('','$name','$doorno','$street','$additional','$city', '$pincode', '$state')");
echo '<script>alert("Your Address got submitted"); location.replace(document.referrer);</script>';

?>
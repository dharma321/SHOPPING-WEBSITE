<!DOCTYPE html>
<html>
<head>
<title>Address</title>
<!-- custom-theme -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Elegant Feedback Form  Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body class="agileits_w3layouts">
    <h1 class="agile_head text-center">Submit your address</h1>
    <div class="w3layouts_main wrap">
	  <h3>Provide your address here </h3>
	    <form action="address/feedback.php" method="post" class="agile_form">
			<input type="text" placeholder="Your Name " name="name" required="" /><br>
			<input type="text" placeholder="Door Number " name="doorno"/><br>
			<input type="text" placeholder="Street " name="street"  /><br>
			<input type="text" placeholder="Additional Information (optional)" name="additional"/><br>
						<input type="text" placeholder="City" name="city"/><br>
						<input type="text" placeholder="Pincode" name="pincode"/><br>
						<input type="text" placeholder="State" name="state"/><br>


			<center><input type="submit" value="Submit Address" class="agileinfo" /></center>
			
	  </form>
	 </div>
	<form method="POST" action="cart.php">
	
	<input type="submit" role="button" value="Go Back to cart" class="btn btn-primary"/>
	
	<div class="copyright text-center">
	<p>Copyright &copy <a >smart shopping</a> Store. All Rights Reserved.</p>
	<p>This website is developed by Dharma & Chidvilash</p>	</div>
</body>
</html>


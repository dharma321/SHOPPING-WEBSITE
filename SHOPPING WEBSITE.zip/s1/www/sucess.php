<?php
require_once 'configDB.php';
echo '<pre>'; print_r($POST);

$sql = "INSERT INTO payment_laser (payment_id, order_id, signature_hash)
VALUES('".$POST[razorpay_payment_id]."','".$_POST['razorpay_order_id']."','".$POST['razorpay_signature']."')";



if($conn->query($sql)==TRUE) {
	echo "New record created sucessfully";
}	else{
		echo "Error:".$sql."<br>".$conn->error;
	}
	
$conn->close();
die;?>
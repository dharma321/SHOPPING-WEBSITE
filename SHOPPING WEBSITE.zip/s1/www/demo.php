<html>
<head>
<title> Razorpay payment Gateway </title>
<style>
.booking-div {
	padding: 15px;
	box-shadow: inset 0 0 0 1px #e0e5e9;
	border: 5px solid #fbfbfc;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	margin-bottom: 30px;
	background-color: #fff;
	width: 350px;
	margin: 0% 10%;
}
.b-fields .b-f-div label {
	background: #dbdbdb;
	font-size: 12px;
	margin-top: 0;
	position: absolute;
	padding: 10px;
	border-radius: 5px 0 0 5px;
	color: #787878;
	width: 60px;
	text-align: center;
}
input {
	width:100%;
	height:35px;
	border-radius: 4px;
	border: 1px solid #528ff0;
	padding-left: 5px;
}
</style>
</head>
<body style="  background-image: -webkit-linear-gradient(90deg,#528ff0,#528ff096, #528ff02b);">
<center>
<div style="margin:8% 0 0">
<h1 style="font-size: 40px;font-family: sans-serif;"</h1>
</div>
<div class="booking-div">
<div class="booking-fields">
<form action="pay.php" method="post">
<table style="width: 100%;  font-family: sans-serif; text-align: left;color: #345d9f;">
<tbody>
<tr>
<th>Customer Name</th>
</tr>
<tr>
<td><input type="text" name="CUSTOMER_NAME" value="Kovvuri Dharma Reddy"></td>
</tr>
<tr>
<th>Customer Email</th>
</tr>
<tr>
<td><input type="text" name="CUSTOMER_EMAIL" value="dharmaapt@gmail.com"></td>
</tr>
<tr>
<th>Customer Mobile</th>
</tr>
<tr>
<td><input type="text" name="CUSTOMER_MOBILE" value="8978378960"></td>
</tr>
<tr>
<th>Payment Amount (In RazorPay Amt to be in subunit of current. Eg. 100000 = Rs.100)</th>
</tr>
<tr>
<td><input type="text" name="PAY_AMT" value="10000"></td>
</tr>
<tr>
<td><input type="submit" value="Pay Now"></td>
</tr>
</tbody>
</table>
</form>
</div>
</center>
</body>
</html>

